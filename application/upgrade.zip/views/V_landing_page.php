

<!-- Full Width Column -->
<div class="content-wrapper " >
    <div class="container">
      <!-- Content Header (Page header) -->
      <!-- Main content -->
      <section class="content">
      <div class="row"> 
        <div class="col-md-9">
          <div class="box">
             <h3> LANDING </h3> 
          </div>
        </div>
        <div class="col-md-3">
          <!-- search -->
          <div class="box">
          <h3> LANDING </h3> 
          </div>
          <!-- search -->
          <!-- filter -->
          <div class="box">
          <h3> LANDING </h3> 
          </div>
          <!-- filter -->
        </div>
      </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.container -->
  </div>
</div>

 